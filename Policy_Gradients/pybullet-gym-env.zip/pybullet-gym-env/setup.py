from setuptools import setup

setup(
    name='modified_gym_env',
    version='0.0.1',
    install_requires=['gym', 'pybullet', 'pybulletgym'],
    author="Jacob Johnson",
    author_email="jjj025@ucsd.edu"
)
